<?php get_header() ?>

<?php
    get_bridge('theme')->{'_c_void_Hero@init'}();
    get_bridge('theme')->{'_c_void_HpFields@init'}();
    get_bridge('theme')->{'_c_void_News@init'}();
    get_bridge('theme')->{'_c_void_HpSpeech@init'}();
    get_bridge('theme')->{'_c_void_HpOthers@init'}();
?>

<?php get_footer() ?>