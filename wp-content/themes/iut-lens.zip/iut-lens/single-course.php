
<?php get_header() ?>

    <?php get_bridge('theme')->{'_c_void_CourseInfos@init'}(); ?>
    <?php get_bridge('theme')->{'_c_void_CourseAssets@init'}(); ?>
    <?php get_bridge('theme')->{'_c_void_CourseGoals@init'}(); ?>

<?php get_footer() ?>