<div class="column-6 mgb-2_5">
    <span class="title text-blue mgb-1_5"><?=$title; ?></span>
    <?=$content; ?>
</div>