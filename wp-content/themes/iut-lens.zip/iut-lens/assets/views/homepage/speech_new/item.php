<div class="swiper-slide size-40">
    <div class="title" data-swiper-parallax="-300">
        <h4 class="title text-blue mgb-1_5"><?=$title; ?></h4>
    </div>
    <div class="text-white" data-swiper-parallax="-100">
        <?=$content; ?>
    </div>
</div>